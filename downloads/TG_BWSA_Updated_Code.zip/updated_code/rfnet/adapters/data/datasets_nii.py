# import os
# import torch
# from torch.utils.data import Dataset

# from .rand import Uniform
# from .transforms import Rot90, Flip, Identity, Compose
# from .transforms import GaussianBlur, Noise, Normalize, RandSelect
# from .transforms import RandCrop, CenterCrop, Pad,RandCrop3D,RandomRotion,RandomFlip,RandomIntensityChange
# from .transforms import NumpyType
# from .data_utils import pkload

# import numpy as np
# import nibabel as nib

# HGG = []
# LGG = []
# for i in range(0, 260):
#     HGG.append(str(i).zfill(3))
# for i in range(336, 370):
#     HGG.append(str(i).zfill(3))
# for i in range(260, 336):
#     LGG.append(str(i).zfill(3))

# mask_array = np.array([[True, False, False, False], [False, True, False, False], [False, False, True, False], [False, False, False, True],
#                       [True, True, False, False], [True, False, True, False], [True, False, False, True], [False, True, True, False], [False, True, False, True], [False, False, True, True], [True, True, True, False], [True, True, False, True], [True, False, True, True], [False, True, True, True],
#                       [True, True, True, True]])

# class Brats_loadall_nii(Dataset):
#     def __init__(self, transforms='', root=None, modal='all', num_cls=4, train_file='train.txt'):
#         data_file_path = os.path.join(root, train_file)
#         with open(data_file_path, 'r') as f:
#             datalist = [i.strip() for i in f.readlines()]
#         datalist.sort()

#         volpaths = []
#         for dataname in datalist:
#             volpaths.append(os.path.join(root, 'vol', dataname+'_vol.npy'))

#         self.volpaths = volpaths
#         self.transforms = eval(transforms or 'Identity()')
#         self.names = datalist
#         self.num_cls = num_cls
#         if modal == 'flair':
#             self.modal_ind = np.array([0])
#         elif modal == 't1ce':
#             self.modal_ind = np.array([1])
#         elif modal == 't1':
#             self.modal_ind = np.array([2])
#         elif modal == 't2':
#             self.modal_ind = np.array([3])
#         elif modal == 'all':
#             self.modal_ind = np.array([0,1,2,3])

#     def __getitem__(self, index):

#         volpath = self.volpaths[index]
#         name = self.names[index]
        
#         x = np.load(volpath)
#         segpath = volpath.replace('vol', 'seg')
#         y = np.load(segpath)
#         x, y = x[None, ...], y[None, ...]

#         x,y = self.transforms([x, y])

#         x = np.ascontiguousarray(x.transpose(0, 4, 1, 2, 3))# [Bsize,channels,Height,Width,Depth]
#         _, H, W, Z = np.shape(y)
#         y = np.reshape(y, (-1))
#         one_hot_targets = np.eye(self.num_cls)[y]
#         yo = np.reshape(one_hot_targets, (1, H, W, Z, -1))
#         yo = np.ascontiguousarray(yo.transpose(0, 4, 1, 2, 3))

#         x = x[:, self.modal_ind, :, :, :]

#         x = torch.squeeze(torch.from_numpy(x), dim=0)
#         yo = torch.squeeze(torch.from_numpy(yo), dim=0)

#         mask_idx = np.random.choice(15, 1)
#         mask = torch.squeeze(torch.from_numpy(mask_array[mask_idx]), dim=0)
#         return x, yo, mask, name

#     def __len__(self):
#         return len(self.volpaths)

# class Brats_loadall_test_nii(Dataset):
#     def __init__(self, transforms='', root=None, modal='all', test_file='test.txt'):
#         data_file_path = os.path.join(root, test_file)
#         with open(data_file_path, 'r') as f:
#             datalist = [i.strip() for i in f.readlines()]
#         datalist.sort()
#         volpaths = []
#         for dataname in datalist:
#             volpaths.append(os.path.join(root, 'vol', dataname+'_vol.npy'))
#         self.volpaths = volpaths
#         self.transforms = eval(transforms or 'Identity()')
#         self.names = datalist
#         if modal == 'flair':
#             self.modal_ind = np.array([0])
#         elif modal == 't1ce':
#             self.modal_ind = np.array([1])
#         elif modal == 't1':
#             self.modal_ind = np.array([2])
#         elif modal == 't2':
#             self.modal_ind = np.array([3])
#         elif modal == 'all':
#             self.modal_ind = np.array([0,1,2,3])

#     def __getitem__(self, index):

#         volpath = self.volpaths[index]
#         name = self.names[index]
#         x = np.load(volpath)
#         segpath = volpath.replace('vol', 'seg')
#         y = np.load(segpath).astype(np.uint8)
#         x, y = x[None, ...], y[None, ...]
#         x,y = self.transforms([x, y])

#         x = np.ascontiguousarray(x.transpose(0, 4, 1, 2, 3))# [Bsize,channels,Height,Width,Depth]
#         y = np.ascontiguousarray(y)

#         x = x[:, self.modal_ind, :, :, :]
#         x = torch.squeeze(torch.from_numpy(x), dim=0)
#         y = torch.squeeze(torch.from_numpy(y), dim=0)

#         return x, y, name

#     def __len__(self):
#         return len(self.volpaths)

# class Brats_loadall_val_nii(Dataset):
#     def __init__(self, transforms='', root=None, settype='train', modal='all'):
#         data_file_path = os.path.join(root, 'val.txt')
#         with open(data_file_path, 'r') as f:
#             datalist = [i.strip() for i in f.readlines()]
#         datalist.sort()
#         volpaths = []
#         for dataname in datalist:
#             volpaths.append(os.path.join(root, 'vol', dataname+'_vol.npy'))
#         self.volpaths = volpaths
#         self.transforms = eval(transforms or 'Identity()')
#         self.names = datalist
#         if modal == 'flair':
#             self.modal_ind = np.array([0])
#         elif modal == 't1ce':
#             self.modal_ind = np.array([1])
#         elif modal == 't1':
#             self.modal_ind = np.array([2])
#         elif modal == 't2':
#             self.modal_ind = np.array([3])
#         elif modal == 'all':
#             self.modal_ind = np.array([0,1,2,3])

#     def __getitem__(self, index):

#         volpath = self.volpaths[index]
#         name = self.names[index]
#         x = np.load(volpath)
#         segpath = volpath.replace('vol', 'seg')
#         y = np.load(segpath).astype(np.uint8)
#         x, y = x[None, ...], y[None, ...]
#         x,y = self.transforms([x, y])

#         x = np.ascontiguousarray(x.transpose(0, 4, 1, 2, 3))# [Bsize,channels,Height,Width,Depth]
#         y = np.ascontiguousarray(y)
#         x = x[:, self.modal_ind, :, :, :]

#         x = torch.squeeze(torch.from_numpy(x), dim=0)
#         y = torch.squeeze(torch.from_numpy(y), dim=0)

#         mask = mask_array[index%15]
#         mask = torch.squeeze(torch.from_numpy(mask), dim=0)
#         return x, y, mask, name

#     def __len__(self):
#         return len(self.volpaths)





import os
import torch
from torch.utils.data import Dataset

from .rand import Uniform
from .transforms import Rot90, Flip, Identity, Compose
from .transforms import GaussianBlur, Noise, Normalize, RandSelect
from .transforms import RandCrop, CenterCrop, Pad, RandCrop3D, RandomRotion, RandomFlip, RandomIntensityChange
from .transforms import NumpyType
from .data_utils import pkload

import numpy as np
import nibabel as nib

# For BraTS2023, you might not need to split into HGG and LGG;
# however, if you want to maintain these lists (or for legacy compatibility), they are preserved.
HGG = []
LGG = []
for i in range(0, 260):
    HGG.append(str(i).zfill(3))
for i in range(336, 370):
    HGG.append(str(i).zfill(3))
for i in range(260, 336):
    LGG.append(str(i).zfill(3))

# Use one fixed mask array indicating all modalities are present.
mask_array = np.array([[True, True, True, True]])

class Brats_loadall_nii(Dataset):
    def __init__(self, transforms='', root=None, modal='all', num_cls=4, train_file='train.txt'):
        data_file_path = os.path.join(root, train_file)
        with open(data_file_path, 'r') as f:
            datalist = [i.strip() for i in f.readlines()]
        datalist.sort()

        volpaths = []
        for dataname in datalist:
            volpaths.append(os.path.join(root, 'vol', dataname + '_vol.npy'))

        self.volpaths = volpaths
        self.transforms = eval(transforms or 'Identity()')
        self.names = datalist
        self.num_cls = num_cls
        # Update modality indices for BraTS2023:
        # t1c --> index 0, t1n --> index 1, t2f --> index 2, t2w --> index 3.
        if modal == 't1c':
            self.modal_ind = np.array([0])
        elif modal == 't1n':
            self.modal_ind = np.array([1])
        elif modal == 't2f':
            self.modal_ind = np.array([2])
        elif modal == 't2w':
            self.modal_ind = np.array([3])
        elif modal == 'all':
            self.modal_ind = np.array([0, 1, 2, 3])

    def __getitem__(self, index):
        volpath = self.volpaths[index]
        name = self.names[index]
        
        x = np.load(volpath)
        segpath = volpath.replace('vol', 'seg')
        y = np.load(segpath)
        x, y = x[None, ...], y[None, ...]  # Add batch dimension

        x, y = self.transforms([x, y])

        # Rearrange x to [B, channels, H, W, D] (assuming stored shape is [B, H, W, D, channels])
        x = np.ascontiguousarray(x.transpose(0, 4, 1, 2, 3))
        # For y, reshape into one-hot representation.
        _, H, W, Z = np.shape(y)
        y = np.reshape(y, (-1))
        one_hot_targets = np.eye(self.num_cls)[y]
        yo = np.reshape(one_hot_targets, (1, H, W, Z, -1))
        yo = np.ascontiguousarray(yo.transpose(0, 4, 1, 2, 3))

        x = x[:, self.modal_ind, :, :, :]

        x = torch.squeeze(torch.from_numpy(x), dim=0)
        yo = torch.squeeze(torch.from_numpy(yo), dim=0)

        # Use the fixed mask (all True) for each sample.
        mask = torch.squeeze(torch.from_numpy(mask_array[0]), dim=0)
        return x, yo, mask, name

    def __len__(self):
        return len(self.volpaths)


class Brats_loadall_test_nii(Dataset):
    def __init__(self, transforms='', root=None, modal='all', test_file='test.txt'):
        data_file_path = os.path.join(root, test_file)
        with open(data_file_path, 'r') as f:
            datalist = [i.strip() for i in f.readlines()]
        datalist.sort()
        volpaths = []
        for dataname in datalist:
            volpaths.append(os.path.join(root, 'vol', dataname + '_vol.npy'))
        self.volpaths = volpaths
        self.transforms = eval(transforms or 'Identity()')
        self.names = datalist
        if modal == 't1c':
            self.modal_ind = np.array([0])
        elif modal == 't1n':
            self.modal_ind = np.array([1])
        elif modal == 't2f':
            self.modal_ind = np.array([2])
        elif modal == 't2w':
            self.modal_ind = np.array([3])
        elif modal == 'all':
            self.modal_ind = np.array([0, 1, 2, 3])

    def __getitem__(self, index):
        volpath = self.volpaths[index]
        name = self.names[index]
        x = np.load(volpath)
        segpath = volpath.replace('vol', 'seg')
        y = np.load(segpath).astype(np.uint8)
        x, y = x[None, ...], y[None, ...]
        x, y = self.transforms([x, y])

        x = np.ascontiguousarray(x.transpose(0, 4, 1, 2, 3))
        y = np.ascontiguousarray(y)

        x = x[:, self.modal_ind, :, :, :]
        x = torch.squeeze(torch.from_numpy(x), dim=0)
        y = torch.squeeze(torch.from_numpy(y), dim=0)

        return x, y, name

    def __len__(self):
        return len(self.volpaths)


class Brats_loadall_val_nii(Dataset):
    def __init__(self, transforms='', root=None, settype='train', modal='all'):
        data_file_path = os.path.join(root, 'val.txt')
        with open(data_file_path, 'r') as f:
            datalist = [i.strip() for i in f.readlines()]
        datalist.sort()
        volpaths = []
        for dataname in datalist:
            volpaths.append(os.path.join(root, 'vol', dataname + '_vol.npy'))
        self.volpaths = volpaths
        self.transforms = eval(transforms or 'Identity()')
        self.names = datalist
        if modal == 't1c':
            self.modal_ind = np.array([0])
        elif modal == 't1n':
            self.modal_ind = np.array([1])
        elif modal == 't2f':
            self.modal_ind = np.array([2])
        elif modal == 't2w':
            self.modal_ind = np.array([3])
        elif modal == 'all':
            self.modal_ind = np.array([0, 1, 2, 3])

    def __getitem__(self, index):
        volpath = self.volpaths[index]
        name = self.names[index]
        x = np.load(volpath)
        segpath = volpath.replace('vol', 'seg')
        y = np.load(segpath).astype(np.uint8)
        x, y = x[None, ...], y[None, ...]
        x, y = self.transforms([x, y])

        x = np.ascontiguousarray(x.transpose(0, 4, 1, 2, 3))
        y = np.ascontiguousarray(y)
        x = x[:, self.modal_ind, :, :, :]

        x = torch.squeeze(torch.from_numpy(x), dim=0)
        y = torch.squeeze(torch.from_numpy(y), dim=0)

        # For validation, use a fixed mask (all True)
        mask = torch.squeeze(torch.from_numpy(mask_array[0]), dim=0)
        return x, y, mask, name

    def __len__(self):
        return len(self.volpaths)
